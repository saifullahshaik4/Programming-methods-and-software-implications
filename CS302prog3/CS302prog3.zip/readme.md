This program implements Dynamic binding (upcasting, downcasting). The specfic heiarchy is decribed in the Pet.h file description. Using a 2-3-4 tree, we allow the user to select from 3 pet types for adoption (derived classes) and we then prompt for general data and then speacilized data based on the pet type selected. We store that data intialized to a newly created object pointer of the derived class and then send it to be inserted into the pet base class pointer array in our node into the 2-3-4 tree, This program allows insert, remove all, and display options with the tre

to compile the code write make in the command line. then use ./output to execute. 




